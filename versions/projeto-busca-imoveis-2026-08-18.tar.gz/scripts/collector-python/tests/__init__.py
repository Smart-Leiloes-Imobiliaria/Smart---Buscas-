"""Testes do collector Python."""
