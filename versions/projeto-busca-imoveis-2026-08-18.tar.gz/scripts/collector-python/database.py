import os
import json
import psycopg
from psycopg.rows import dict_row


DATABASE_URL = os.getenv("DATABASE_URL")


def get_connection():
    if not DATABASE_URL:
        raise RuntimeError(
            "DATABASE_URL não definida no ambiente."
        )

    return psycopg.connect(
        DATABASE_URL,
        row_factory=dict_row,
    )


def get_disabled_source_codes():
    """Códigos de fontes pausadas no painel /admin (tabela `source`).

    Os códigos do coletor Python são sempre MAIÚSCULOS (ex.: "VIVAREAL"),
    enquanto a tabela `source` usa códigos minúsculos (ex.: "vivareal"),
    então a comparação é feita normalizando para maiúsculas.
    """
    try:
        with get_connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute("SELECT code FROM source WHERE enabled = FALSE")
                return {row["code"].upper() for row in cursor.fetchall()}
    except psycopg.errors.UndefinedTable:
        return set()


def ensure_properties_table():
    sql = """
    CREATE TABLE IF NOT EXISTS properties (
        id BIGSERIAL PRIMARY KEY,

        source TEXT NOT NULL,
        source_id TEXT NOT NULL,

        advertiser_name TEXT,

        title TEXT,
        description TEXT,

        sale_price NUMERIC,
        rental_price NUMERIC,

        city TEXT,
        state TEXT,
        neighborhood TEXT,
        street TEXT,

        bedrooms INTEGER,
        bathrooms INTEGER,
        suites INTEGER,
        parking_spaces INTEGER,

        condominium_fee NUMERIC,
        iptu NUMERIC,

        usable_area NUMERIC,
        total_area NUMERIC,


        property_type TEXT,

        image_url TEXT,
        image_urls JSONB,
        url TEXT NOT NULL,

        country TEXT,
        date_posted TIMESTAMPTZ,

        status TEXT NOT NULL DEFAULT 'ACTIVE',

        first_seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        last_seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

        UNIQUE (source, source_id)
    );
    """

    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(sql)
            cur.execute("""
                ALTER TABLE properties
                ADD COLUMN IF NOT EXISTS neighborhood TEXT;
            """)
            cur.execute("""
                ALTER TABLE properties
                ADD COLUMN IF NOT EXISTS street TEXT;
            """)
            cur.execute("""
                ALTER TABLE properties
                ADD COLUMN IF NOT EXISTS bathrooms INTEGER;
            """)
            cur.execute("""
                ALTER TABLE properties
                ADD COLUMN IF NOT EXISTS suites INTEGER;
            """)
            cur.execute("""
                ALTER TABLE properties
                ADD COLUMN IF NOT EXISTS parking_spaces INTEGER;
            """)
            cur.execute("""
                ALTER TABLE properties
                ADD COLUMN IF NOT EXISTS condominium_fee NUMERIC;
            """)
            cur.execute("""
                ALTER TABLE properties
                ADD COLUMN IF NOT EXISTS iptu NUMERIC;
            """)
            cur.execute("""
                ALTER TABLE properties
                ADD COLUMN IF NOT EXISTS image_urls JSONB;
            """)

        conn.commit()


def upsert_property(property_data):
    normalized_property = property_data.copy()
    normalized_property["image_urls"] = json.dumps(
        normalized_property.get("image_urls", [])
    )

    sql = """
    INSERT INTO properties (
        source,
        source_id,
        title,
        advertiser_name,
        description,
        sale_price,
        rental_price,
        city,
        state,
        neighborhood,
        street,
        bedrooms,
        bathrooms,
        suites,
        parking_spaces,
        usable_area,
        condominium_fee,
        iptu,
        property_type,
        image_url,
        image_urls,
        url,
        country,
        date_posted,
        status,
        last_seen_at,
        updated_at
    )
    VALUES (
        %(source)s,
        %(source_id)s,
        %(title)s,
        %(advertiser_name)s,
        %(description)s,
        %(sale_price)s,
        %(rental_price)s,
        %(city)s,
        %(state)s,
        %(neighborhood)s,
        %(street)s,
        %(bedrooms)s,
        %(bathrooms)s,
        %(suites)s,
        %(parking_spaces)s,
        %(usable_area)s,
        %(condominium_fee)s,
        %(iptu)s,
        %(property_type)s,
        %(image_url)s,
        %(image_urls)s::jsonb,
        %(url)s,
        %(country)s,
        %(date_posted)s,
        'ACTIVE',
        NOW(),
        NOW()
    )

    ON CONFLICT (source, source_id)
    DO UPDATE SET
        title = EXCLUDED.title,
        advertiser_name = EXCLUDED.advertiser_name,
        description = EXCLUDED.description,
        sale_price = EXCLUDED.sale_price,
        rental_price = EXCLUDED.rental_price,
        city = EXCLUDED.city,
        state = EXCLUDED.state,
        neighborhood = EXCLUDED.neighborhood,
        street = EXCLUDED.street,
        bedrooms = EXCLUDED.bedrooms,
        bathrooms = EXCLUDED.bathrooms,
        suites = EXCLUDED.suites,
        parking_spaces = EXCLUDED.parking_spaces,
        usable_area = EXCLUDED.usable_area,
        condominium_fee = EXCLUDED.condominium_fee,
        iptu = EXCLUDED.iptu,
        property_type = EXCLUDED.property_type,
        image_url = EXCLUDED.image_url,
        image_urls = EXCLUDED.image_urls,
        url = EXCLUDED.url,
        country = EXCLUDED.country,
        date_posted = EXCLUDED.date_posted,
        status = 'ACTIVE',
        last_seen_at = NOW(),
        updated_at = NOW();
    """

    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(sql, normalized_property)

        conn.commit()


def upsert_properties(properties):
    if not properties:
        return 0

    sql = """
    INSERT INTO properties (
        source,
        source_id,
        title,
        advertiser_name,
        description,
        sale_price,
        rental_price,
        city,
        state,
        neighborhood,
        street,
        bedrooms,
        bathrooms,
        suites,
        parking_spaces,
        usable_area,
        condominium_fee,
        iptu,
        property_type,
        image_url,
        image_urls,
        url,
        country,
        date_posted,
        status,
        last_seen_at,
        updated_at
    )
    VALUES (
        %(source)s,
        %(source_id)s,
        %(title)s,
        %(advertiser_name)s,
        %(description)s,
        %(sale_price)s,
        %(rental_price)s,
        %(city)s,
        %(state)s,
        %(neighborhood)s,
        %(street)s,
        %(bedrooms)s,
        %(bathrooms)s,
        %(suites)s,
        %(parking_spaces)s,
        %(usable_area)s,
        %(condominium_fee)s,
        %(iptu)s,
        %(property_type)s,
        %(image_url)s,
        %(image_urls)s::jsonb,
        %(url)s,
        %(country)s,
        %(date_posted)s,
        'ACTIVE',
        NOW(),
        NOW()
    )

    ON CONFLICT (source, source_id)
    DO UPDATE SET
        title = EXCLUDED.title,
        advertiser_name = EXCLUDED.advertiser_name,
        description = EXCLUDED.description,
        sale_price = EXCLUDED.sale_price,
        rental_price = EXCLUDED.rental_price,
        city = EXCLUDED.city,
        state = EXCLUDED.state,
        neighborhood = EXCLUDED.neighborhood,
        street = EXCLUDED.street,
        bedrooms = EXCLUDED.bedrooms,
        bathrooms = EXCLUDED.bathrooms,
        suites = EXCLUDED.suites,
        parking_spaces = EXCLUDED.parking_spaces,
        usable_area = EXCLUDED.usable_area,
        condominium_fee = EXCLUDED.condominium_fee,
        iptu = EXCLUDED.iptu,
        property_type = EXCLUDED.property_type,
        image_url = EXCLUDED.image_url,
        image_urls = EXCLUDED.image_urls,
        url = EXCLUDED.url,
        country = EXCLUDED.country,
        date_posted = EXCLUDED.date_posted,
        status = 'ACTIVE',
        last_seen_at = NOW(),
        updated_at = NOW();
    """

    normalized_properties = []

    for property_data in properties:
        item = property_data.copy()
        item["image_urls"] = json.dumps(
            item.get("image_urls", [])
        )
        normalized_properties.append(item)

    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.executemany(
                sql,
                normalized_properties,
            )

        conn.commit()

    return len(properties)


def claim_property_search(search_id=None, max_attempts=3):
    with get_connection() as conn:
        with conn.cursor() as cur:
            if search_id:
                cur.execute(
                    """
                    SELECT * FROM property_searches
                    WHERE id = %s
                      AND status = 'PENDING'
                      AND attempts < %s
                      AND (next_attempt_at IS NULL OR next_attempt_at <= NOW())
                    FOR UPDATE SKIP LOCKED
                    """,
                    (search_id, max_attempts),
                )
            else:
                cur.execute(
                    """
                    SELECT * FROM property_searches
                    WHERE status = 'PENDING'
                      AND attempts < %s
                      AND (next_attempt_at IS NULL OR next_attempt_at <= NOW())
                    ORDER BY COALESCE(next_attempt_at, created_at), created_at
                    FOR UPDATE SKIP LOCKED
                    LIMIT 1
                    """,
                    (max_attempts,),
                )

            search = cur.fetchone()
            if not search:
                return None

            cur.execute(
                """
                UPDATE property_searches
                SET status = 'RUNNING',
                    attempts = attempts + 1,
                    started_at = COALESCE(started_at, NOW()),
                    completed_at = NULL,
                    next_attempt_at = NULL,
                    last_heartbeat_at = NOW(),
                    error_message = NULL,
                    updated_at = NOW()
                WHERE id = %s
                """,
                (search["id"],),
            )

        conn.commit()

    search["status"] = "RUNNING"
    search["attempts"] = int(search["attempts"]) + 1
    search["next_attempt_at"] = None
    return search


def get_property_search(search_id):
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT * FROM property_searches WHERE id = %s",
                (search_id,),
            )
            return cur.fetchone()


def heartbeat_property_search(search_id):
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE property_searches
                SET last_heartbeat_at = NOW(),
                    updated_at = NOW()
                WHERE id = %s AND status = 'RUNNING'
                """,
                (search_id,),
            )
        conn.commit()


def retry_property_search(search_id, error_message, delay_seconds):
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE property_searches
                SET status = 'PENDING',
                    next_attempt_at = NOW() + (%s * INTERVAL '1 second'),
                    last_heartbeat_at = NULL,
                    completed_at = NULL,
                    error_message = %s,
                    updated_at = NOW()
                WHERE id = %s AND status = 'RUNNING'
                """,
                (delay_seconds, str(error_message)[:2000], search_id),
            )
        conn.commit()


def recover_stale_property_searches(
    stale_after_seconds,
    max_attempts,
    retry_delay_seconds,
):
    with get_connection() as conn:
        with conn.cursor() as cur:
            stale_condition = """
                status = 'RUNNING'
                AND COALESCE(last_heartbeat_at, updated_at, started_at)
                    < NOW() - (%s * INTERVAL '1 second')
            """
            cur.execute(
                f"""
                UPDATE property_searches
                SET status = 'FAILED',
                    completed_at = NOW(),
                    last_heartbeat_at = NULL,
                    error_message = 'Execução interrompida e tentativas esgotadas.',
                    updated_at = NOW()
                WHERE {stale_condition}
                  AND attempts >= %s
                """,
                (stale_after_seconds, max_attempts),
            )
            failed = cur.rowcount

            cur.execute(
                f"""
                UPDATE property_searches
                SET status = 'PENDING',
                    next_attempt_at = NOW() + (%s * INTERVAL '1 second'),
                    last_heartbeat_at = NULL,
                    completed_at = NULL,
                    error_message = 'Execução anterior interrompida; nova tentativa agendada.',
                    updated_at = NOW()
                WHERE {stale_condition}
                  AND attempts < %s
                """,
                (
                    retry_delay_seconds,
                    stale_after_seconds,
                    max_attempts,
                ),
            )
            retried = cur.rowcount
        conn.commit()

    return {"retried": retried, "failed": failed}


def link_property_search_results(search_id, properties):
    property_ids = []

    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "DELETE FROM property_search_results WHERE search_id = %s",
                (search_id,),
            )

            for property_data in properties:
                cur.execute(
                    """
                    SELECT id FROM properties
                    WHERE source = %s AND source_id = %s
                    """,
                    (
                        property_data["source"],
                        property_data["source_id"],
                    ),
                )
                row = cur.fetchone()
                if not row:
                    continue

                property_ids.append(row["id"])
                cur.execute(
                    """
                    INSERT INTO property_search_results (search_id, property_id)
                    VALUES (%s, %s)
                    ON CONFLICT DO NOTHING
                    """,
                    (search_id, row["id"]),
                )

        conn.commit()

    return property_ids


def complete_property_search(search_id, properties_found):
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE property_searches
                SET status = 'COMPLETED',
                    properties_found = %s,
                    completed_at = NOW(),
                    next_attempt_at = NULL,
                    last_heartbeat_at = NULL,
                    error_message = NULL,
                    updated_at = NOW()
                WHERE id = %s
                """,
                (properties_found, search_id),
            )
        conn.commit()


def fail_property_search(search_id, error_message):
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE property_searches
                SET status = 'FAILED',
                    error_message = %s,
                    completed_at = NOW(),
                    next_attempt_at = NULL,
                    last_heartbeat_at = NULL,
                    updated_at = NOW()
                WHERE id = %s
                """,
                (str(error_message)[:2000], search_id),
            )
        conn.commit()
