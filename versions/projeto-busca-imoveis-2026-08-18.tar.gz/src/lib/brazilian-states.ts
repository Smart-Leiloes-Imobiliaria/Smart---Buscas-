export const BRAZILIAN_STATES = [
  "AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO",
  "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI",
  "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO",
] as const;

export const isBrazilianState = (value: string) =>
  BRAZILIAN_STATES.includes(
    value.toUpperCase() as (typeof BRAZILIAN_STATES)[number],
  );
